create schema ggy2016011422 collate utf8mb4_0900_ai_ci;

--购物车表
create table cart
(
	cart_id int unsigned auto_increment
		primary key,
	cart_count int null,
	good_id int unsigned null,
	user_id int unsigned null
)
comment '购物车';
--商品表
create table goods
(
	good_id int unsigned auto_increment comment '商品id',
	good_status tinyint null comment '0发布，1审核，2售卖中，4待支付，5运输，6完成',
	good_category varchar(32) null comment '分类',
	good_name varchar(32) null comment '商品名',
	good_describe varchar(255) null comment '商品描述',
	good_price float null comment '商品价格',
	good_count int null comment '商品数量',
	good_p1 varchar(255) null comment '商品照片1',
	good_p2 varchar(255) null comment '招牌你2',
	good_p3 varchar(255) null comment '照片3',
	good_create datetime null comment '创建时间',
	user_id int unsigned null,
	constraint goods_good_id_uindex
		unique (good_id)
)
comment '商品表';

alter table goods
	add primary key (good_id);

--订单表
create table orders
(
	order_id int unsigned auto_increment comment '用户id'
		primary key,
	user_id int unsigned null comment '用户id',
	good_id int unsigned null comment '商品id',
	order_createdate datetime null comment '订单生成时间',
	order_paydate datetime null comment '支付时间',
	order_exchangedate datetime null comment '送达中转室时间',
	order_finish datetime null comment '完成时间',
	good_count int null comment '购买商品数量',
	order_change datetime null comment '离开中转时间',
	order_status tinyint null comment '1未支付，2已支付，3送达中转，4离开中转，5完成'
)
comment '订单';

--用户信息表
create table user_info
(
	id int unsigned auto_increment
		primary key,
	username varchar(50) not null,
	password char(32) not null,
	mail varchar(32) not null,
	status tinyint default 0 not null,
	`check` tinyint default 0 not null,
	enroll_date datetime null,
	update_date datetime null,
	login_date datetime null,
	constraint user_info_username_uindex
		unique (username)
)
comment '用户基本信息';
