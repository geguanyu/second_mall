package com.fan;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Date;


@SpringBootTest
class SecondMallApplicationTests {
    @Autowired
    JavaMailSenderImpl mailSender;
    @Test
    void contextLoads() {
        SimpleMailMessage mailMessage = new SimpleMailMessage();
        mailMessage.setSubject("HELLO VUE!");
        mailMessage.setText("dfdfdsfdsffds");
        mailMessage.setTo("15730872593@163.com");
        mailMessage.setFrom("799715919@qq.com");
        mailSender.send(mailMessage);


    }

}
