package com.fan.controller;

import com.fan.pojo.cart.Cart;
import com.fan.service.CartService;
import com.fan.utils.ResultUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin
@ResponseBody
public class CartContoller {
    @Autowired
    private CartService cartService;
    @PostMapping("/cart/add-to-cart")
    public ResultUtils addCart(@RequestBody Cart cart){
        //System.out.println(cart.toString());
        return cartService.addCart(cart);
    }
    @GetMapping("/cart/getCartList")
    public ResultUtils getCartList(@RequestParam int user_id){
        return cartService.getCartList(user_id);
    }
    @DeleteMapping("/cart/deleteById")
    public ResultUtils deleteCart(@RequestParam int id){
        return  cartService.deleteCart(id);
    }

}
