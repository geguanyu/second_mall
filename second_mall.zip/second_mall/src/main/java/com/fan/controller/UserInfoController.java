package com.fan.controller;

import com.fan.config.api.CommonResult;
import com.fan.pojo.UserInfo;
import com.fan.pojo.UserSup;
import com.fan.pojo.user.LoginUserPojo;
import com.fan.service.UserInfoService;
import com.fan.service.UserSupService;
import com.fan.utils.MD5;
import com.fan.utils.Paging;
import com.fan.utils.ResultUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/user")
@ResponseBody
public class UserInfoController {
    @Autowired
    UserInfoService userServe ;
    @Autowired
    UserSupService supService;
    MD5 md5 = new MD5();

    //注册，初始化用户
    @PostMapping("/user_inserInit" )
    public CommonResult insertInit(@RequestBody Map map) {
        String name,pwd,email,dateString;
        name = map.get("name").toString();
        pwd= md5.getMD5(map.get("pwd").toString());
        email= map.get("email").toString();
        dateString = map.get("date").toString();
        userServe.insertInit(name,pwd,email,dateString,dateString);
        return  CommonResult.create("注册成功！！");
    }

    //注册时检查是否有重名
    @GetMapping("/user_getByName" )
    public CommonResult getByName(@RequestParam String name ) {

        String username=userServe.getByName(name);
        if(username!=null) {
            return CommonResult.failed("账号已经存在，请重新输入");
        }
        return  CommonResult.success("用户名不存在,可以创建");

    }
    //登录用户，
    @PostMapping("/user_login" )
    public ResultUtils login(@RequestBody LoginUserPojo userPojo) {
       return  userServe.login(userPojo);
    }
    //获取用户列表
    @PostMapping("/user_queryAll")
    public CommonResult queryAll(@RequestBody Map map){
        String search = map.get("search").toString();
        Integer pagenum = Integer.valueOf(map.get("pagenum").toString());
        Integer pageSize = Integer.valueOf(map.get("pageSize").toString());
        List<UserInfo> userList = null;
        userList =userServe.queryAll(pagenum,pageSize);
        int total = userServe.countAll();
        Paging page = new Paging();
        page.setData(userList);
        page.setPagenum(pagenum);
        page.setPageSize(pageSize);
        page.setTotal(total);
        if(userList!=null) {
            return CommonResult.success(page, "查询成功");
        }
        return  CommonResult.failed("请求失败");
    }
    //改变用户状态，禁用与否
    @PostMapping("/user_changeStatus")
    public CommonResult changeStatus(@RequestBody Map map){
        Integer id = Integer.valueOf(map.get("id").toString());
        Byte status = Byte.valueOf(map.get("status").toString());
        userServe.changeStatus(id,status);
        return  CommonResult.success("成功修改用户状态！！");
    }
    //删除用户
    @GetMapping("/user_delete")
    public CommonResult deleteUser(@RequestParam Integer id){
        boolean flag = false;
        flag = userServe.deleteUser(id);
        return CommonResult.success("成功删除用户！！");
    }


    /**
     *通过用户id获得用户信息(info+sup)
     * @param id
     * @return
     *  id:0,
     *  username:'fan'
     *  email:'151515419@163.com',
     *  sex:0,
     *  tell:'',
     *  wechat:'',
     *  address:'',
     */

    @GetMapping("/getUserAllById")
    public ResultUtils<Map> getUserAll(@RequestParam Integer id){
        //System.out.println(this.getClass()+":"+id);
        UserInfo userInfo = userServe.getUserById(id);
        UserSup userSup = supService.getUserSupById(id);
        Map<String,String> map = new HashMap<>();
        map.put("id",userInfo.getId().toString());
        map.put("username",userInfo.getUsername());
        map.put("email",userInfo.getMail());
        if(userSup!=null) {
            map.put("sex", userSup.getSup_sex().toString());
            map.put("tell", userSup.getSup_tell());
            map.put("wechat", userSup.getSup_wechat());
            map.put("address", userSup.getSup_address());
        }else{
            map.put("sex", "null");
            map.put("tell", "null");
            map.put("wechat", "null");
            map.put("address", "null");
        }
        return  ResultUtils.success(map);
    }
    @GetMapping("/getUserById")
    public ResultUtils getUserIdByname(@RequestParam String name){
        return  userServe.getUserIdByName(name);
    }
}
