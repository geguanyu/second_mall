package com.fan.controller;

import com.fan.utils.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.io.File;
import java.io.IOException;

@RestController
@CrossOrigin
public class ImageController {
    @CrossOrigin
    @PostMapping("api/imgs")
    public String coversUpload(MultipartFile file) throws Exception {
        String folder = "E:/GraduationProject/second_mall_vue/src/assets/img";
        File imageFolder = new File(folder);
        int n = file.getOriginalFilename().length();
        //注意string.split() 特殊字符的处理
        //获得图片后缀名字
        String suffix = file.getOriginalFilename().split("\\.")[1];
        //System.out.println(suffix);
        File f = new File(imageFolder, StringUtils.getRandomString(6) + "."+suffix);
        if (!f.getParentFile().exists())
            f.getParentFile().mkdirs();
        try {
            file.transferTo(f);
            String imgURL = f.getName();
            return imgURL;
        } catch (IOException e) {
            e.printStackTrace();
            return "";
        }
    }
}
