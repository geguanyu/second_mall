package com.fan.controller;


import com.fan.pojo.order.CreateOrderPojo;
import com.fan.service.OrderService;
import com.fan.utils.ResultUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin
@ResponseBody
public class OrderController {
    @Autowired
    private OrderService orderService;
    @PostMapping("/order/create-order")
    public ResultUtils createOrder(@RequestBody CreateOrderPojo orderPojo){
        return orderService.createOrder(orderPojo);
    }
    @GetMapping("/order/getOrderList")
    public ResultUtils getOrderListById(@RequestParam Integer id){
        if(id<0) id=null;
        return  orderService.getOrderListById(id);
    }
    @GetMapping("/order/changeOrderStatus")
    public ResultUtils changeStatus(@RequestParam Integer order_id,@RequestParam Byte order_status){
        return  orderService.changeStatus(order_id,order_status);
    }
    @GetMapping("/order/payOrder")
    public ResultUtils payOrder(@RequestParam Integer order_id,@RequestParam String date){
        return  orderService.payOrder(order_id,date);
    }
    @GetMapping("/order/toExchange")
    public ResultUtils toExchange(@RequestParam Integer order_id,@RequestParam String date){
        return  orderService.toExchange(order_id,date);
    }
    @GetMapping("/order/leaveExchange")
    public ResultUtils leaveExchange(@RequestParam Integer order_id,@RequestParam String date){
        return  orderService.leaveExchange(order_id,date);
    }
    @GetMapping("/order/finshOrder")
    public ResultUtils finshOrder(@RequestParam Integer order_id,@RequestParam String date){
        return  orderService.finishOrder(order_id,date);
    }
    @GetMapping("/oder/getOderById")
    public ResultUtils getOderById(@RequestParam Integer order_id){
        return  orderService.getOrderById(order_id);
    }
}
