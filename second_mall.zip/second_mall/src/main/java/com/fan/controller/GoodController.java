package com.fan.controller;

import com.fan.pojo.Good;
import com.fan.service.GoodService;
import com.fan.utils.ResultUtils;
import io.swagger.models.auth.In;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@CrossOrigin
@ResponseBody

public class GoodController {
    @Autowired
    GoodService goodService;

    /**
     *         user_id:0,good_category:'',//类别 good_name:'',//商品名 good_describe:'',//商品描述
     *         good_price:0,//价格 good_postdate:'',//发布日期 good_status:0,//商品状态 good_count:1,//商品数量
     *         good_p1:'', good_p2:'', good_p3:'',
     * @return
     */
    @PostMapping("/good/post-good")
    public ResultUtils postGood(@RequestBody Map map){
        Good good = new Good();
        Integer user_id = Integer.valueOf(map.get("user_id").toString());good.setUser_id(user_id);
        String good_category = map.get("category").toString();
        good.setGood_category(good_category);
        String  good_name = map.get("good_name").toString();good.setGood_name(good_name);
        String  good_describe = map.get("good_describe").toString();good.setGood_describe(good_describe);
        Integer good_price = Integer.valueOf(map.get("good_price").toString());good.setGood_price(good_price);
        String good_postdate = map.get("good_postdate").toString();good.setGood_create(good_postdate);
        Byte good_status = Byte.valueOf( map.get("good_status").toString());good.setGood_status(good_status);
        Integer good_count = Integer.valueOf(map.get("good_count").toString());good.setGood_count(good_count);
        String good_p1 = map.get("good_p1").toString();good.setGood_p1(good_p1);
        String good_p2 = map.get("good_p2").toString();good.setGood_p2(good_p2);
        String good_p3 = map.get("good_p3").toString();good.setGood_p3(good_p3);
        goodService.addGood(good);
       return ResultUtils.success();
    }
    //获得状态为0的商品
    @GetMapping("/good/goodList-uncheck")
    public ResultUtils getGoodList_uncheck(){
        return ResultUtils.success(goodService.getGoodListByStatus((byte) 0));
    }

    /**
     *
     * @param good_id
     * 根据商品id更改状态为1
     * @return
     */
    @GetMapping("/good/good-passcheck")
    public ResultUtils goodPassCheck(@RequestParam Integer good_id){
        goodService.changeGoodStatus(good_id,(byte)1);
        return  ResultUtils.success();
    }

    /**
     *
     * @param good_id
     * 更改商品状态为-1
     * @return
     */
    @GetMapping("/good/nupass-check")
    public ResultUtils goodNuPassCheck(@RequestParam Integer good_id){
        goodService.changeGoodStatus(good_id,(byte)-1);
        return  ResultUtils.success();
    }

    /**
     * 通过商品类别获得状态为1的商品
     * @param serach
     * @return
     */
    @GetMapping("/good/getGoodlist-by-category")
    public ResultUtils getGoodListByQuery(@RequestParam String serach){
        return goodService.getGoodByQuery(serach);
    }
//    public ResultUtils getGoodListByCategoryAndStatus1(@RequestParam String serach){
//        return ResultUtils.success(goodService.getGoodByCategoryAndStatus(serach,(byte) 1));
//    }

    @GetMapping("/good/goodmore-id")
    public ResultUtils getGoodById(@RequestParam int id){
        return ResultUtils.success(goodService.getGoodById(id));
    }

    @GetMapping("/good/getGoodAllByUser")
    public ResultUtils getGoodAllByUser(@RequestParam Integer userId){
        return  goodService.getGoodListAllByUserId(userId);
    }
}
