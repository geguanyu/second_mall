package com.fan.utils;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResultUtils<T> {
    private long code;//状态码
    private String message;//提示信息
    private T data;//数据封装
    /**
     *请求成功
     * @param data
     * @param message
     * @param <T>
     * @return
     */
    public static<T> ResultUtils<T> success(T data,String message){
        return  new ResultUtils<T>(ResultCode.SUCCESS.getCode(),message,data);
    }
    public static<T> ResultUtils<T> success(T data){
        return  new ResultUtils<T>(ResultCode.SUCCESS.getCode(),ResultCode.SUCCESS.getMessage(),data);
    }
    public static<T> ResultUtils<T> success(){
        return  new ResultUtils<T>(ResultCode.SUCCESS.getCode(),ResultCode.SUCCESS.getMessage(),null);
    }
    public static<T> ResultUtils<T> success(String message){
        return  new ResultUtils<T>(ResultCode.SUCCESS.getCode(),message,null);
    }
    /**
     * 操作失败
     * @param data
     * @param message
     * @param <T>
     * @return
     */
    public static<T> ResultUtils<T> failed(T data,String message){
        return  new ResultUtils<T>(ResultCode.FAILED.getCode(),message,data);
    }
    public static<T> ResultUtils<T> failed(String message){
        return  new ResultUtils<T>(ResultCode.FAILED.getCode(),message,null);
    }
    public static<T> ResultUtils<T> failed(){
        return  new ResultUtils<T>(ResultCode.FAILED.getCode(),ResultCode.FAILED.getMessage(),null);
    }

    /**
     * 创建成功
     * @param data
     * @param message
     * @param <T>
     * @return
     */
    public static<T> ResultUtils<T> created(T data,String message){
        return  new ResultUtils<T>(ResultCode.CREATED.getCode(),message,data);
    }
    public static<T> ResultUtils<T> created(String message){
        return  new ResultUtils<T>(ResultCode.CREATED.getCode(),message,null);
    }
    public static<T> ResultUtils<T> created(){
        return  new ResultUtils<T>(ResultCode.CREATED.getCode(),ResultCode.CREATED.getMessage(),null);
    }
    /**
     * 删除成功
     * @param data
     * @param message
     * @param <T>
     * @return
     */
    public static<T> ResultUtils<T> deleted(T data,String message){
        return  new ResultUtils<T>(ResultCode.DELETED.getCode(),message,data);
    }
    public static<T> ResultUtils<T> deleted(String message){
        return  new ResultUtils<T>(ResultCode.DELETED.getCode(),message,null);
    }
    public static<T> ResultUtils<T> deleted(){
        return  new ResultUtils<T>(ResultCode.DELETED.getCode(),ResultCode.DELETED.getMessage(),null);
    }
    /**
     * 没有相关权限
     * @param data
     * @param message
     * @param <T>
     * @return
     */
    public static<T> ResultUtils<T> forbidden(T data,String message){
        return  new ResultUtils<T>(ResultCode.FORBIDDEN.getCode(),message,data);
    }
    public static<T> ResultUtils<T> forbidden(String message){
        return  new ResultUtils<T>(ResultCode.FORBIDDEN.getCode(),message,null);
    }
}
/**
 * 枚举了一些常用API操作码
 * Created by macro on 2019/4/19.
 */

enum  ResultCode {
    SUCCESS(200, "请求成功"),
    CREATED(201,"创建成功"),
    DELETED(204,"删除成功 "),
    FAILED(500, "操作失败"),
    FORBIDDEN(403, "没有相关权限");
    private long code;
    private String message;
    private ResultCode(long code, String message) {
        this.code = code;
        this.message = message;
    }
    public long getCode() {
        return code;
    }
    public String getMessage() {
        return message;
    }
}
