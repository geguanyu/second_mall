package com.fan.utils;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class Paging<T> {
    private  T data;
    private int pageSize;
    private  int pagenum;
    private int total;
}
