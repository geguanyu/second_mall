package com.fan.service;

import com.fan.mapper.GoodMapper;
import com.fan.mapper.OrderMapper;
import com.fan.mapper.UserInfoMapper;
import com.fan.pojo.UserInfo;
import com.fan.pojo.order.CreateOrderPojo;
import com.fan.pojo.order.Order;
import com.fan.pojo.order.OrderListPojo;
import com.fan.utils.ResultUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class OrderService {
    @Autowired
    private OrderMapper orderMapper;
    @Autowired
    private GoodMapper goodMapper;
    @Autowired
    private UserInfoMapper userMapper;
    public ResultUtils createOrder(CreateOrderPojo orderPojo) {
        orderPojo.setOrder_satus((byte) 0);
        System.out.println(orderPojo.getGood_id());
        int count = goodMapper.getGoodCount(orderPojo.getGood_id());
        int remain = count - orderPojo.getGood_count();
        if(remain<0) return ResultUtils.failed("库存不足！！");
        boolean change = goodMapper.setGoodCount(orderPojo.getGood_id(),remain);
        if(!change) return  ResultUtils.failed("数据库出错");
        boolean success = orderMapper.createOrder(orderPojo);
        if(!success) return ResultUtils.failed("数据库出现错误");
        return ResultUtils.success();
    }
    public ResultUtils getOrderListById(Integer id){
        List<Order> orderList = orderMapper.getOrderListById(id);
        List<OrderListPojo> orderListPojos = new ArrayList<>();

        for(Order o:orderList){
            int userid= o.getUser_id();
            int goodId = o.getGood_id();
            OrderListPojo pojo = new OrderListPojo(o,goodMapper.getGoodById(goodId),userMapper.getUserById(userid).getUsername());
            orderListPojos.add(pojo);
        }
        return  ResultUtils.success(orderListPojos,"获取订单成功");
    }
    public ResultUtils changeStatus(Integer orderId,Byte status){
        orderMapper.changeOrderStatus(orderId,status);
        return ResultUtils.success();
    }
    public ResultUtils payOrder(Integer orderId,String date){
        orderMapper.payOrder(orderId,date);
        return  ResultUtils.success();
    }
    public ResultUtils toExchange(Integer orderId,String date){
        orderMapper.toExchange(orderId,date);
        return  ResultUtils.success();
    }
    public ResultUtils leaveExchange(Integer orderId,String date){
        orderMapper.leaveExchange(orderId, date);
        return  ResultUtils.success();
    }
    public ResultUtils finishOrder(Integer orderId,String date){
        orderMapper.finishOrder(orderId,date);
        return  ResultUtils.success();
    }
    public ResultUtils back(Integer orderId){
        orderMapper.changeOrderStatus(orderId,(byte) 5);
        return  ResultUtils.success();
    }
    public ResultUtils getOrderById(Integer orderId){
        return  ResultUtils.success(orderMapper.getOrderByOrderId(orderId));
    }
}
