package com.fan.service;

import com.fan.mapper.UserInfoMapper;
import com.fan.pojo.UserInfo;
import com.fan.pojo.user.LoginUserPojo;
import com.fan.utils.MD5;
import com.fan.utils.ResultUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserInfoService {
    @Autowired
    UserInfoMapper userInfoMapper;
    //注册时初始化用户
    public boolean insertInit(String  name,String pwd,String email,String enroll_time,String update_time){
        UserInfo userInfo = new UserInfo();
        userInfo.setUsername(name);
        userInfo.setPassword(pwd);
        userInfo.setMail(email);
        userInfo.setEnroll_date(enroll_time);
        userInfo.setUpdate_date(update_time);
        userInfoMapper.insertInit(userInfo);
        return true;
    }
    //通过用户名查询用户
    public String getByName(String username){
        return userInfoMapper.getUserByName(username).getUsername();
    }
    //查找所有用户
    public List<UserInfo> queryAll(int pageNum,int pageSize){
        List<UserInfo> userInfos =null;
        int index =(pageNum-1)*pageSize;
        userInfos=userInfoMapper.queryAll(index,pageSize);
        return userInfos;
    }
    //登录
    public ResultUtils login(LoginUserPojo user){
        MD5 md5 = new MD5();
        UserInfo userInfo = userInfoMapper.login(user.getUsername(),md5.getMD5(user.getPassword()));
        if(userInfo==null) {return ResultUtils.failed("用户名或密码错误");}
        else if(userInfo.getCheck()!=1) {return  ResultUtils.failed("未经过学籍认证，请前往认证");}
        else if(userInfo.getStatus()==1||userInfo.getStatus().equals((byte) 1)){return  ResultUtils.failed("该账号已经被禁用，请联系管理员");}
        else {return  ResultUtils.success(userInfo,"成功登录！");}
    }
    //修改用户状态
    public boolean changeStatus(int id,byte status){
        if(status==0) status=1;
        else status=0;
        userInfoMapper.changeStatus(id,status);
        return  true;
    }
    //删除用户
    public boolean deleteUser(int id){
        return userInfoMapper.deleteUser(id);
    }
    //编辑用户
    public boolean editUser(UserInfo user){
        return  true;
    }
    //统计用户
    public int countAll(){
        return userInfoMapper.countAll();
    }
    public UserInfo getUserById(Integer id){
        return userInfoMapper.getUserById(id);
    }
    public ResultUtils getUserIdByName(String name){
        return ResultUtils.success(userInfoMapper.getUserIdByName(name));
    }
}
