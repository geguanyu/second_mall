package com.fan.service;

import com.fan.mapper.GoodMapper;
import com.fan.pojo.Good;
import com.fan.utils.ResultUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GoodService {
    @Autowired
    GoodMapper goodMapper;
    public boolean addGood(Good good){
        return goodMapper.addgood(good);
    }
    public List<Good> getGoodListByStatus(byte status){
        return  goodMapper.getGoodListByStatus(status);
    }
    public boolean changeGoodStatus(int good_id,byte status){
        return  goodMapper.changeGoodStatus(good_id,status);
    }

    public List<Good> getGoodByCategoryAndStatus(String category,byte status){
        return  goodMapper.getGoodByCategoryAndStatus(category,status);
    }
    public ResultUtils getGoodByQuery(String queryStr){
        if(queryStr.equals("all")||queryStr.equals("书籍")||queryStr.equals("文体用品")||queryStr.equals("电子产品")
                ||queryStr.equals("服装")||queryStr.equals("饰品精品")||queryStr.equals("其他")){
            return  ResultUtils.success(goodMapper.getGoodByCategoryAndStatus(queryStr,(byte) 1));
        }
        char[] chars = queryStr.toCharArray();
        StringBuffer buffer = new StringBuffer();
        buffer.append("%");
        for(int i=0;i<chars.length;i++){
            buffer.append(chars[i]);
            buffer.append('%');
        }
        String query = buffer.toString();
        System.out.println(query);
        List<Good> goodList = goodMapper.getGoodByQuery(query,(byte) 1);
        return ResultUtils.success(goodList);
    }
    public Good getGoodById(int id){
        return  goodMapper.getGoodById(id);
    }

    public boolean setGoodCount(int id,int count){
        return  goodMapper.setGoodCount(id,count);
    }
    public int getGoodCount(int id) {
        return goodMapper.getGoodCount(id);
    }
    public ResultUtils getGoodListAllByUserId(Integer userId){
        return ResultUtils.success(goodMapper.getGoodListAllByUserId(userId));
    }
}
