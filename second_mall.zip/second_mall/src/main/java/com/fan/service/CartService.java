package com.fan.service;

import com.fan.mapper.CartMapper;
import com.fan.mapper.GoodMapper;
import com.fan.mapper.UserInfoMapper;
import com.fan.pojo.Good;
import com.fan.pojo.UserInfo;
import com.fan.pojo.cart.Cart;
import com.fan.pojo.cart.CartList;
import com.fan.utils.ResultUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CartService {
    @Autowired
    private CartMapper cartMapper;
    @Autowired
    private GoodMapper goodMapper;
    @Autowired
    private UserInfoMapper userInfoMapper;
    public ResultUtils addCart(Cart cart){
        boolean success = cartMapper.addCart(cart);
        if(!success) return ResultUtils.failed("添加购物车失败");
        int count = goodMapper.getGoodCount(cart.getGood_id());
        int remain = count - cart.getCart_count();
        if(remain<0) return ResultUtils.failed("库存不足！");
        return  ResultUtils.success();
    }
    public ResultUtils getCartList(int userid){
        List<Cart> list = cartMapper.getCartList(userid);
        List<CartList> cartLists = new ArrayList<>();
        for(Cart cart:list){
            Good good = goodMapper.getGoodById(cart.getGood_id());
            UserInfo userInfo = userInfoMapper.getUserById(cart.getUser_id());
            CartList cartList = new CartList(cart,good,userInfo);
            cartLists.add(cartList);
        }
        return ResultUtils.success(cartLists);
    }
    public ResultUtils deleteCart(int id){
        return  ResultUtils.success(cartMapper.deleteCart(id),"删除成功");
    }
}
