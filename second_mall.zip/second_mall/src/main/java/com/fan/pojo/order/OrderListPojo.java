package com.fan.pojo.order;

import com.fan.pojo.Good;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class OrderListPojo extends Order{
    private String usernameSell;//用户名
    private String good_category;//分类
    private String good_name;//名称
    private String good_describe;//描述
    private Integer good_price;//单价
    private String good_p1;//商品照片

    public OrderListPojo(Order order, Good good, String usernameSell){
       super(order.getOrder_id(),order.getUser_id(),order.getGood_id(),order.getGood_count(),order.getOrder_createdate(),order.getOrder_paydate(),order.getOrder_exchangedate(),order.getOrder_change(),order.getOrder_finish(),order.getOrder_status());
       this.usernameSell = usernameSell;
       this.good_category = good.getGood_category();
       this.good_name = good.getGood_name();
       this.good_describe = good.getGood_describe();
       this.good_price = good.getGood_price();
       this.good_p1 = good.getGood_p1();
    }
}
