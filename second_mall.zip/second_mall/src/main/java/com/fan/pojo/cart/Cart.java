package com.fan.pojo.cart;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Cart {
    private Integer cart_id;//购物车id
    private int cart_count;//数量
    private Integer good_id;//商品id
    private Integer user_id;//用户id
}
