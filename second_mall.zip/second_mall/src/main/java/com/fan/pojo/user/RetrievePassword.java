package com.fan.pojo.user;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RetrievePassword {
    private Integer id;
    private String username;//用户名
    private String mail;//邮箱，找回密码
    private String authcode;
}
