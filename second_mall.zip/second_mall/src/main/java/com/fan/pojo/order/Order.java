package com.fan.pojo.order;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Order {
    private Integer order_id;
    private Integer user_id;
    private Integer good_id;
    private Integer good_count;
    private String order_createdate;
    private String order_paydate;
    private String order_exchangedate;
    private String order_change;
    private String order_finish;
    private Byte order_status;
}
