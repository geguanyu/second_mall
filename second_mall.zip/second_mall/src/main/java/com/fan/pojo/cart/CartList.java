package com.fan.pojo.cart;

import com.fan.pojo.Good;
import com.fan.pojo.UserInfo;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CartList extends Cart{
    private String username;//用户名
    private Byte check;//是否学籍证明，0未，1已经验证
    private String good_name;//名称
    private String good_describe;//描述
    private Integer good_price;//单价
    private int good_count;//数量
    private String good_p1;//商品照片
    public CartList(Cart cart, Good good, UserInfo user) {
        super(cart.getCart_id(), cart.getCart_count(), cart.getGood_id(), cart.getUser_id());
        this.username = user.getUsername();
        this.check = user.getCheck();
        this.good_name = good.getGood_name();
        this.good_describe = good.getGood_describe();
        this.good_price = good.getGood_price();
        this.good_count = good.getGood_count();
        this.good_p1 = good.getGood_p1();
    }
}
