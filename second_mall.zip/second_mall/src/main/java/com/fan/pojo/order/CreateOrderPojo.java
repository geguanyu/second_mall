package com.fan.pojo.order;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CreateOrderPojo {
    private Integer user_id;
    private Integer good_id;
    private Integer good_count;
    private String order_createdate;
    public Byte order_satus;
}
