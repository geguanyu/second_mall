package com.fan.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Good {
    private Integer good_id;//商品id
    private Byte good_status;//商品状态 -1 审核未通过 0刚发布 1审核通过
    private String good_category;//分类
    private String good_name;//名称
    private String good_describe;//描述
    private Integer good_price;//单价
    private int good_count;//数量
    private String good_p1;//商品照片
    private String good_p2;
    private String good_p3;
    private String good_create;//创建日期
    private int user_id;//发布者id
}
