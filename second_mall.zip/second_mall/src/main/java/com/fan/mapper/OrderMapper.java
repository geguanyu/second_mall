package com.fan.mapper;

import com.fan.pojo.order.CreateOrderPojo;
import com.fan.pojo.order.Order;
import io.swagger.models.auth.In;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface OrderMapper {
    boolean createOrder(CreateOrderPojo pojo);
    List<Order> getOrderListById(Integer id);
    boolean changeOrderStatus(Integer id,Byte status);
    boolean payOrder(Integer id,String date);
    boolean toExchange(Integer id,String date);
    boolean leaveExchange(Integer id,String date);
    boolean finishOrder(Integer id,String date);
    Order getOrderByOrderId(Integer oderId);


}
