package com.fan.mapper;

import com.fan.pojo.UserInfo;
import com.fan.pojo.user.ChangePassword;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface UserInfoMapper {
    //注册时初始化用户
    boolean insertInit(UserInfo userInfo);
    //通过用户名查询用户
    UserInfo getUserByName(String username);
    Integer getUserIdByName(String username);
    //查找所有用户
    List<UserInfo> queryAll(int index, int pageSize);
    //登录
    UserInfo login(String username, String password);
    //修改用户状态
    boolean changeStatus(int id,byte status);
    //删除用户
    boolean deleteUser(int id);
    //编辑用户
    boolean editUser(UserInfo user);
    //通过用户
    int countAll();
    UserInfo getUserById(Integer id);
    boolean changePasswordById(ChangePassword changePassword);
}
