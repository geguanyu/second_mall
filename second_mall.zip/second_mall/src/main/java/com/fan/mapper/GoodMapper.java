package com.fan.mapper;

import com.fan.pojo.Good;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface GoodMapper {
    boolean addgood(Good good);
    List<Good> getGoodListByStatus(byte status);
    boolean changeGoodStatus(int good_id,byte status);
    List<Good> getGoodByCategoryAndStatus(String category,byte status);
    List<Good> getGoodByQuery(String queryStr,byte status);
    Good getGoodById(int id);
    boolean setGoodCount(int id,int count);
    int getGoodCount(int id);
    List<Good> getGoodListAllByUserId(Integer userId);
}
