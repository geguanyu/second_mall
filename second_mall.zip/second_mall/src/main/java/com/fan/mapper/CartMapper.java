package com.fan.mapper;

import com.fan.pojo.cart.Cart;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface CartMapper {
    boolean addCart(Cart cart);
    List<Cart> getCartList(int userid);
    boolean deleteCart(int id);
}
