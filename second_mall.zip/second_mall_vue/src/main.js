import Vue from 'vue'
import App from './App.vue'
import router from './router'

// 注册插件

//引入全局配置
import 'assets/css/global.css'

import { Message ,Button,Form,FormItem,Input,
        Container,Header,Aside,Main,Footer,
        Menu,Submenu,MenuItemGroup,MenuItem,
        Breadcrumb,BreadcrumbItem,Card,
        Row,Col,Table,TableColumn,Switch,
        Pagination,Dialog,Popover,Divider,Link,
        Backtop,DatePicker,Upload,MessageBox,Image,
        InputNumber,Radio,Checkbox,Select,Option,Timeline,
        TimelineItem,Tabs,TabPane,Carousel,CarouselItem,Tooltip
} from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
Vue.prototype.$msgbox = MessageBox
Vue.prototype.$alert = MessageBox.alert
Vue.prototype.$confirm = MessageBox.confirm
Vue.prototype.$prompt = MessageBox.prompt
Vue.prototype.$message= Message
Vue.prototype.$confirm =MessageBox
Vue.use(Tooltip)
Vue.use(CarouselItem);
Vue.use(Carousel);
Vue.use(TabPane);
Vue.use(Tabs);
Vue.use(TimelineItem);
Vue.use(Timeline);
Vue.use(Option);
Vue.use(Select);
Vue.use(Checkbox);
Vue.use(Radio);
Vue.use(InputNumber);
Vue.use(Image);
Vue.use(Upload);
Vue.use(DatePicker);
Vue.use(Backtop);
Vue.use(Divider);
Vue.use(Link);
Vue.use(Button);
Vue.use(Form);
Vue.use(FormItem);
Vue.use(Input);
Vue.use(Container);
Vue.use(Header);
Vue.use(Aside);
Vue.use(Main);
Vue.use(Footer);
Vue.use(Menu);
Vue.use(Submenu);
Vue.use(MenuItemGroup);
Vue.use(MenuItem);
Vue.use(Breadcrumb);
Vue.use(BreadcrumbItem);
Vue.use(Card);
Vue.use(Row);
Vue.use(Col);
Vue.use(Table);
Vue.use(TableColumn);
Vue.use(Switch);
Vue.use(Pagination);
Vue.use(Dialog);
Vue.use(Popover);

import axios from 'axios'
Vue.prototype.$axios = axios;
axios.defaults.baseURL='http://127.0.0.1:8088'
axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';
// 请求在到达服务器之前，先会调用use中的这个回调函数来添加请求头信息
axios.interceptors.request.use(config => {
  // console.log(config)
  // 为请求头对象，添加token验证的Authorization字段
  config.headers.Authorization = window.sessionStorage.getItem('token')
  // 在最后必须 return config
  return config
})

Vue.config.productionTip = false


new Vue({
  router,
  render: h => h(App)
}).$mount('#app')
