<template>
<div>
</div>
</template>

<script>


export default {


data(){
return{
    good:{
        good_id:1,
        good_p1:'',
        good_des:'',
        good_name:'',
        good_count:'',
    },
    user:{
        user_id:1,
        user_name:'',
    },
    order:{
        
    },
}
},


methods:{
}


}


</script>




<style>


</style>