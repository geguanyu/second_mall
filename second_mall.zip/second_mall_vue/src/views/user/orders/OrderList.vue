<template>
<el-row>
    <div>
        <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/user_home' }">首页</el-breadcrumb-item>
            <el-breadcrumb-item>订单中心</el-breadcrumb-item>
        </el-breadcrumb>
    </div>
    <el-col :span="8" v-for="item in orderList" :key="item.index" >
        <el-card class="240px">
            <div class="order">
                <div class="cell p-img"><el-image :src="item.good_p1"  fit="full" style="height:120px" ></el-image></div>
                <div class="cell p-text">
                <div><span style="font-size:10px">{{item. good_name}}-{{item.good_describe}}</span></div>
                <div><span style="font-size:15px;color: blue">单价：￥{{item.good_price}}</span></div>
                <div><span style="font-size:15px;color: blue">数量：￥{{item.good_count}}</span></div>
                <div><span style="font-size:15px;color: red">总价：￥{{item.good_price*item.good_count}}</span></div>
                <div><span style="font-size:15px;color: red">{{item.order_zt}}</span></div>
                </div>
            </div>
            <div>
                <el-button type="primary" @click="gopay(item.index)">支付订单</el-button>
                <el-button type="success" @click="finish(item.index)">完成订单</el-button>
                <el-button type="danger" @click="more(item.order_id)">详情</el-button> 
            </div>
        </el-card>
        <el-dialog
            title="用户详细信息" :visible.sync="moreDialogVisible" width="60%">
            <order :orderid="orderId"></order>
            <span slot="footer" class="dialog-footer">
            <el-button @click="moreDialogVisible = false">取 消</el-button>
            <el-button type="primary" @click="moreDialogVisible = false">确 定</el-button>
            </span>
            </el-dialog>
    </el-col>
</el-row>

</template>

<script>
import {dateFormat} from '../../../utils/dateUtil'
import Order from '../../../components/good/Order'
    export default {
    components:{'order':Order},
    data(){
        return{
            orderId:0,
            userid:'',
            moreDialogVisible:false,
            orderList:[{
                index:0,
                cart_id:1,
                good_id:0,
                username:'范广胜',//商品发布者
                good_name:'哇哈哈',
                good_describe:'第三个覅十多个覅一个屌丝发一个屌丝一个',
                good_p1:'https://img2.baidu.com/it/u=2666157028,2545819682&fm=26&fmt=auto&gp=0.jpg',
                good_price:80,
                order_id:544964,
                order_createdate:'2018-04-01 20:46',//0
                order_paydate:'2018-04-06 20:46',//1
                order_changedate:'2018-04-07 20:46',//2
                order_finishdate:'2018-04-08 20:46',//3
                order_status:1,
                good_count:1,
                order_zt:''
            },]
        }
    },
created(){
    let uerId = window.sessionStorage.getItem('userId')
    this.userid = uerId
    this.getOrderList(uerId)
},
methods:{
    getOrderList(uid){
        this.$axios.get("/order/getOrderList",{params:{
            id:uid
        }})
        .then(res => {
            this.orderList = res.data.data;
            for(let i = 0;i<res.data.data.length;i++){
                this.orderList[i].good_p1 = require('../../../assets/img/'+res.data.data[i].good_p1)
                this.orderList[i].index = i
                
                let status = parseInt(this.orderList[i].order_status)
                if(status==0)
                    this.orderList[i].order_zt = '未支付';
                else if(status==1)
                    this.orderList[i].order_zt = '已支付';
                else if(status==2)
                    this.orderList[i].order_zt = '送达中转中心';
                else if(status==3)
                    this.orderList[i].order_zt = '离开中转中心';
                else if(status==4)
                    this.orderList[i].order_zt = '完成';
                else 
                    this.orderList[i].order_zt = 'ok';
            }
        })
        .catch(err => {
            console.error(err); 
        })
    },
    gopay(index){
        let order = this.orderList[index]
        let id = order.order_id;
        let status = order.order_status
        if(status!='0'||status!=0){
            this.$message.error("处于"+order.order_zt+",不能支付！")
            return;
        }
        let date =dateFormat(new Date()) 
        this.$axios.get("/order/payOrder",{params:{
            order_id:id,
            date:date
        }})
        .then(res => {
            console.log(res)
            this.getOrderList(this.userid)
             this.$message.success("完成支付！")
        })
        .catch(err => {
            console.error(err); 
        })
    },
    finish(index){
        let order = this.orderList[index]
        let id = order.order_id;
        let status = order.order_status
        if(status!='3'||status!=3){
            this.$message.error("处于"+order.order_zt+",不能完成订单！！")
            return;
        }
        let date =dateFormat(new Date()) 
        this.$axios.get("/order/finshOrder",{params:{
            order_id:id,
            date:date
        }})
        .then(res => {
            console.log(res)
            this.getOrderList(this.userid)
            this.$message.success("完成订单！")
        })
        .catch(err => {
            console.error(err); 
        })
    },
    more(id){
        this.moreDialogVisible = true
        this.orderId = id
    },
}


}


</script>
<style>
.orderCard{
    height:460 ;
}
.order{
     height: 100%;
     padding-bottom:5px;
     display: inline-block;
     width: 100%;
}
.cell {
    float: left;
    padding: 5px 0 4px;
}
 .p-img {
    position: relative;
    float: left;
    width: 120px;
    height: 80px;
    border: 1px solid #eee;
    margin-right: 10px;
    background: #fff;
    padding: 2px;
    text-align: center;
    overflow: visible;
}
.p-text{
  width: 160px;
  height: 100%;
}
.p-button{
  float:lift;
}
</style>