<template>
<el-container class="home-container">
  <el-header>
    <head-top @find='selectSting'></head-top>
  </el-header>
  <el-container>
    <!-- 侧边栏 -->
    <el-aside width="160px">
      <el-tabs tab-position="left" @tab-click="selectCategory" >
        <el-tab-pane v-for="item in categoryList" :name="''+item.id" :key="item.id" :label="item.category">
        </el-tab-pane>
      </el-tabs>
    </el-aside>
    <el-main>
      <good-list :good_serach="good_select"></good-list>
    </el-main>
  </el-container>
     <back-to-top/> 
</el-container>
</template>
<script>
  import BackToTop from "../../components/BackToTop";
  import HeadTop from "../../components/HeadTop";
  import GoodList from '../../components/good/GoodList';
export default {
  components: {
    "back-to-top":BackToTop,
    "head-top":HeadTop,
    'good-list':GoodList,
    },
    data(){
        return{
          categoryList:[
            {
              id:0,
              category:'首页'
            },
            {
              id:1,
              category:'书籍',
            },{
              id:2,
              category:'文体用品',
            },{
              id:3,
              category:'电子产品',
            },{
              id:4,
              category:'服装',
            },{
              id:5,
              category:'饰品精品',
            },{
              id:6,
              category:'其他',
            },
          ],
          good_select:'all',
        }
    },
    methods:{
        selectCategory(tab, event){
          console.log(tab.label)
          if(tab.label=='首页') 
            this.good_select = 'all'
          else
            this.good_select = tab.label
          console.log(this.good_select)
          //console.log(this.$router);
        },
        selectSting(select){
          this.good_select = select
          console.log(select);
        }
    }

}
</script>

<style>
.home-container{
     height: 100%; 
  }

  .el-header {
    background-color: #fff;
    display: flex;
    justify-content: space-between;
    padding-left: 0;
    align-items: center;
    color: #1f1da5;
    font-size: 20px;
 }
  .el-aside {
    background-color: #dce1e6;
    color: #333;
    text-align: center;
    line-height: 200px;
    width: 80px;
  }
  
  .el-main {
    background-color: #E9EEF3;
    color: #333;
    text-align: center;
    line-height: 160px;
  }
  
  body > .el-container {
    margin-bottom: 40px;
  }
  
  .el-container:nth-child(5) .el-aside,
  .el-container:nth-child(6) .el-aside {
    line-height: 260px;
  }
  
  .el-container:nth-child(7) .el-aside {
    line-height: 320px;
  }

</style>