<template>
<el-container>
    <el-main class="login_contatiner">
    <div >
        <div class="login_box">
            <!-- 头像区域 -->
            <div class="avatar_box">
                <img src="../../../assets/login.jpeg" alt="avatar" />
            </div>
            <!-- 登陆表单 -->
            <el-form class="login_form" label-width="0px" 
                :model="loginform" :rules="loginrules" ref="loginFormRef">
                <!-- 用户名 -->
                <el-form-item prop="username">
                    <el-input  prefix-icon="el-icon-user"
                        v-model="loginform.username" ></el-input>
                </el-form-item>
                <!-- 密码 -->
                <el-form-item prop="password">
                    <el-input  prefix-icon="el-icon-key" 
                        v-model="loginform.password" type="password" ></el-input>
                </el-form-item>
                <!-- 按钮区域 -->
                <el-form-item class="btns">
                    <el-button type="primary" @click="login">登录</el-button>
                    <el-button type="info" @click="resetLoginform">重置</el-button>
                </el-form-item>
                <el-form-item class="btns">
                    <el-button type="text" @click="register">没有账号，请注册</el-button>
                </el-form-item>
            </el-form>
        </div>
    </div>
    </el-main>
</el-container>
</template>
<script>
export default {
    data(){
        var validateCheakName=(rule, value, callback) => {
            const me = this;
            console.log(value);
            this.$axios.get("/user/user_getByName",{params:{name:value}})
            .then(res => {
                console.log(res)
                if(res.data.code==200) {
                    callback(new Error('账号不存在，请注册'));
                } 
                callback();
            })
            .catch(err => {
                callback();
                console.error(err); 
            })
        }
        return{
            logPath:'../../../assets/',
            logsrc:this.logPath+'logo.png',
            loginform:{
                username:'fan',
                password:'123456'
            },
            loginrules:{
                username:[
                    {required: true, message: '请输入用户名', trigger: 'blur'},
                    { min: 2, max: 20, message: '长度在 2到 20个字符', trigger: 'blur'},
                     { validator:validateCheakName, trigger:'blur'}
                    ],
                password:[{required: true, message: '请输入密码', trigger: 'blur'},
                    { min: 4, max: 16, message: '长度在 4 到 16 个字符', trigger: 'blur'}
                    ]
            }

        }

    },
    methods:{
        login(){
            const me = this
            this.$refs.loginFormRef.validate(valid => {
                if(!valid) return;
                this.$axios.post('/user/user_login', {
                    username:this.loginform.username,
                    password:this.loginform.password,
                    
                    })
                    .then(function (response) {
                        console.log(response);
                        if(response.data.code!=200) return me.$message.error(response.data.message);
                        window.sessionStorage.setItem('userId',response.data.data.id);
                        me.$message.success("登录成功！")
                        me.$router.push('/user_home')
                       
                    })
                    .catch(function (error) {
                        console.log(error);
                     });
            })
        },
        resetLoginform(){
            this.$message('重置')
            this.$refs.loginFormRef.resetFields();
        },
        register(){
            this.$router.push('/user_register')
        },
        toAdmin(){
            this.$router.push('/admin_login')
        },
        toAddStudent(){
            this.$router.push( {path: '/user/check',query: { username: this.loginform.username }})
        },
        retrievePassword(){
            this.$router.push('/user/retrieve-password')
        }

    }
    
}
</script>
<style lang="less" scoped>
.login_contatiner{
    height: 600px;
}
.login_box{
    width: 450px;
    height: 500px;
    background-color: #fff;
    border-radius: 3px;
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);

    .avatar_box {
        width: 130px;
        height: 130px;
        border: 1px solid #eee;
        border-radius: 50%;
        padding: 10px;
        box-shadow: 0 0 10px #ddd;
        position: absolute;
        left: 50%;
        transform: translate(-50%, -50%);
        background-color: #fff;
        img {
        width: 100%;
        height: 100%;
        border-radius: 50%;
        background-color: #eee;
        }
    }
}
.login_form {
  position: absolute;
  bottom: 0px;
  width: 100%;
  padding: 0 20px;
  box-sizing: border-box;
}
.btns {
  display: flex;
  justify-content: center;
  line-height:1 ;
}
</style>