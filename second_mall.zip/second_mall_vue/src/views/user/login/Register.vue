<template>
    <div class="login_contatiner">
        <div class="login_box">
            <!-- 头像区域 -->
            <div class="avatar_box">
                <img src="../../../assets/login.jpeg" alt="avatar" />
            </div>
            <!-- 登陆表单 -->
            <el-form class="login_form" status-icon label-width="80px" label-position="right"
                :model="registerform" :rules="registerrules" ref="registerform" >
                <!-- 用户名 -->
                <el-form-item prop="username" label="用户名">
                    <el-input  prefix-icon="el-icon-user"
                        v-model="registerform.username" ></el-input>
                </el-form-item>
                <!-- 密码 -->
                <el-form-item prop="password" label="密码">
                    <el-input  prefix-icon="el-icon-key" 
                        v-model="registerform.password" type="password" autocomplete="off" ></el-input>
                </el-form-item>
                <el-form-item prop="pwd" label="确认密码">
                    <el-input  prefix-icon="el-icon-key" 
                        v-model="registerform.pwd" type="password"  autocomplete="off"></el-input>
                </el-form-item>
                <!-- 邮箱 -->
                <el-form-item prop="email" label="邮箱">
                    <el-input  prefix-icon="el-icon-link" 
                        v-model="registerform.email" type="email" ></el-input>
                </el-form-item>
                <!-- 按钮区域 -->
                <el-form-item class="btns">
                    <el-button type="primary" @click="register">注册</el-button>
                    <el-button type="info" @click="resetLoginform">重置</el-button>
                </el-form-item>
                <el-form-item class="btns">
                    <el-button type="text" @click="backLogin">已有账号，返回登录</el-button>
                </el-form-item>
            </el-form>
        </div>
    </div>
</template>
<script>
export default {
    data(){
        var validateCheakName=(rule, value, callback) => {
            const me = this;
            console.log(value);
            this.$axios.get("/user/user_getByName",{params:{name:value}})
            .then(res => {
                console.log(res)
                if(res.data.code!=200) {
                    callback(new Error('账号重复，请重新输入'));
                } 
                callback();
            })
            .catch(err => {
                callback();
                console.error(err); 
            })

        }
        var validatePass = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入密码'));
        } else {
          if (this.registerform.checkPass !== '') {
            this.$refs.registerform.validateField('pwd');
          }
          callback();
        }
      };
      var validatePass2 = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请再次输入密码'));
        } else if (value !== this.registerform.password) {
          callback(new Error('两次输入密码不一致!'));
        } else {
          callback();
        }
      };
        var checkEmail = (rule, value, callback) => {
            const regEmail = /^\w+@\w+(\.\w+)+$/
            if (regEmail.test(value)) {
                // 合法邮箱
                return callback()
            }
            callback(new Error('请输入合法邮箱'))
        }
        return{
            registerform:{
                username:'',
                password:'',
                pwd:'',
                email:''
            },
            registerrules:{
                username:[
                    {required: true, message: '请输入用户名', trigger: 'blur'},
                    { min: 2, max: 20, message: '长度在 2到 20个字符', trigger: 'blur'},
                    { validator: validateCheakName,trigger: 'blur'}
                    ],
                password:[{required: true, message: '请输入密码', trigger: 'blur'},
                    { min: 4, max: 16, message: '长度在 4 到 16 个字符', trigger: 'blur'},
                    { validator: validatePass,trigger: 'blur'}
                    ],
                    pwd:[{ validator: validatePass2,trigger: 'blur'}],
                    email:[ { required: true, message: '请输入邮箱地址', trigger: 'blur' },
                            { type: 'email', message: '请输入正确的邮箱地址', trigger: 'blur' },
                            {validator:checkEmail,trigger: 'blur'}],
            }

        }

    },
    methods:{
        dateFormat(time) {
                var date=new Date(time);
                var year=date.getFullYear();
                /* 在日期格式中，月份是从0开始的，因此要加0
                 * 使用三元表达式在小于10的前面加0，以达到格式统一  如 09:11:05
                 * */
                var month= date.getMonth()+1<10 ? "0"+(date.getMonth()+1) : date.getMonth()+1;
                var day=date.getDate()<10 ? "0"+date.getDate() : date.getDate();
                var hours=date.getHours()<10 ? "0"+date.getHours() : date.getHours();
                var minutes=date.getMinutes()<10 ? "0"+date.getMinutes() : date.getMinutes();
                var seconds=date.getSeconds()<10 ? "0"+date.getSeconds() : date.getSeconds();
                // 拼接
                return year+"-"+month+"-"+day+" "+hours+":"+minutes+":"+seconds;
            },
        register(){
        // 表单预验证
        // valid：bool类型
        const it = this
        this.$refs.registerform.validate(async valid => {
            const  date = new Date();
            const dateString = it.dateFormat(date);
            if (!valid) return false
            this.$axios.post('/user/user_inserInit', {email: this.registerform.email,name: this.registerform.username,pwd:this.registerform.password,date:dateString})
                    .then(function (response) {
                        console.log(response);
                        if(response.data.code==201){
                            console.log(response.data.message)
                            it.$message.success("注册成功！前往学籍注册");
                            //me.$router.push('/user_login')
                             it.$router.push( {path: '/user/check',query: { username: it.registerform.username }})
                        } 
                    })
                    .catch(function (error) {
                        console.log(error);
                     });
           
        })
        },
        resetLoginform(){
            this.$message('重置')
            this.$refs.registerform.resetFields();
        },
        backLogin(){
             this.$router.push('/user_login')
        }


    }
    
}
</script>
<style lang="less" scoped>
.login_contatiner{
    height: 100%;
}
.login_box{
    width: 450px;
    height: 500px;
    background-color: #fff;
    border-radius: 3px;
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);

    .avatar_box {
        width: 130px;
        height: 130px;
        border: 1px solid #eee;
        border-radius: 50%;
        padding: 10px;
        box-shadow: 0 0 10px #ddd;
        position: absolute;
        left: 50%;
        transform: translate(-50%, -50%);
        background-color: #fff;
        img {
        width: 100%;
        height: 100%;
        border-radius: 50%;
        background-color: #eee;
        }
    }
}
.login_form {
  position: absolute;
  bottom: 0px;
  width: 100%;
  padding: 0 20px;
  box-sizing: border-box;
}
 .btns {
        display: flex;      
        justify-content: center;
    }
</style>