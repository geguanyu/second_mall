<template>
<el-card class="block">
    <div>
    <el-breadcrumb separator-class="el-icon-arrow-right">
        <el-breadcrumb-item :to="{ path: '/user_home' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>{{goodInfo.good_category}}</el-breadcrumb-item>
        <el-breadcrumb-item>商品详情</el-breadcrumb-item>
    </el-breadcrumb>
    </div>
    <div class="img">
        <el-carousel trigger="click">
            <el-carousel-item v-for="item in goodInfo.good_p" :key="item">
                <img :src="item">
            </el-carousel-item>
        </el-carousel>
    </div>
    <div class="text">
        <div class="good-name">
            <span>{{goodInfo.good_name}}</span>
        </div>
        <div>{{goodInfo.good_describe}}</div>
        <div class="text-p"><span style="color:red">￥{{goodInfo.good_price}}</span></div>
        <div class="text-p"><span style="color:#909399">还剩{{good_remain}}件</span></div>
        <div class="text-p"><el-input-number v-model="goodpay.pay_count" @change="handleChange" :min="0" :max="maxcount>5?5:maxcount"></el-input-number></div>
        <div class="text-p"><span>总价：</span><span style="color:red">￥{{goodpay.pay_count*goodInfo.good_price}}</span></div>
        <div class="text-p">
             <el-button type="danger"   @click="addCart" min>加入购物车</el-button>
             <el-button type="success"  @click="payGood" min>购买商品</el-button>
        </div>
        <div class="text-p">
             <el-button type="primary" icon="el-icon-edit" @click="addComment">添加评论</el-button>
        </div>
    </div>
    <div class="comment">
         <el-carousel trigger="click">
            <el-carousel-item v-for="item in commitList" :key="item.index">
                <el-card>
                    <div class="text-p"><span>{{item.username}}</span><span class="comment-cart-date">{{item.create_date}}</span></div>
                    <div class="text-p"></div>
                    <div class="text-p"><span>&nbsp; &nbsp; &nbsp; &nbsp; {{item.content}}</span></div>
                </el-card>
            </el-carousel-item>
        </el-carousel>
    </div>
    <el-dialog
        title="添加评论" :visible.sync="addCommentDialogVisible" width="60%">
        <add-comment :goodid="good_id" @showAddComment='showAddComment'></add-comment>
    </el-dialog>
</el-card>
</template>

<script>
import {dateFormat} from '../../../utils/dateUtil'
import AddComment from '../comment/AddComment'
export default {
    components:{"add-comment":AddComment,},
    data(){
        return{
            good_id:0,
            maxcount:0,
            good_remain:0,
            goodpay:{
                good_id:1,
                user_id:0,
                pay_count:0,
            },
            goodInfo:{
                good_id:'2',
                good_name:'面包',
                good_category:'食物',
                good_describe:'好吃的汉堡',
                good_price:262,//价格
                good_postdate:'',//发布日期
                good_count:1,//商品数
                good_p:[
                    'https://fuss10.elemecdn.com/a/3f/3302e58f9a181d2509f3dc0fa68b0jpeg.jpeg',
                    'https://fuss10.elemecdn.com/1/34/19aa98b1fcb2781c4fba33d850549jpeg.jpeg',
                    'https://fuss10.elemecdn.com/0/6f/e35ff375812e6b0020b6b4e8f9583jpeg.jpeg',
                ],
            },
            addCommentDialogVisible:false,
            commitList:[
            ]
        }
    },
    created(){
        this.good_id=this.$router.history.current.query.good_id
        this.getGoodById(this.good_id)
        this.goodpay.good_id = this.good_id
        this.goodpay.user_id = window.sessionStorage.getItem('userId')
        this.getComment(this.good_id)
    },
    watch:{
        good_id: function(val, oldVal){
            this.getGoodById(val)
            this.goodpay.good_id = val
            this.goodpay.user_id = window.sessionStorage.getItem('userId')
            this.getComment(val)
        },
        addCommentDialogVisible:function(val,old){
            console.log("监控"+val);
            this.getComment(this.good_id)
        }
    },
    methods:{
        getGoodById(id){
            this.$axios.get("/good/goodmore-id",{params:{
                id:id
            }})
            .then(res => {
                this.goodInfo = res.data.data
                // pathimg:'../../../assets/img/',
                    let p1 = require('../../../assets/img/'+res.data.data.good_p1)
                    let p2 = require('../../../assets/img/'+res.data.data.good_p2)
                    let p3 = require('../../../assets/img/'+res.data.data.good_p3)
                this.goodInfo.good_p =[p1,p2,p3]
                console.log("GoodInfo:");
                console.log(this.goodInfo);
                this.good_remain = this.goodInfo.good_count
                this.maxcount = this.goodInfo.good_count

            })
            .catch(err => {
                console.error(err); 
            })
        },
        //加入购物车或购买的数量
        handleChange(value){
            console.log(value)
            this.goodpay.pay_count = value
            this.good_remain = this.maxcount-value
        },
        

        //加入购物车
        addCart(){
            if(this.goodpay.pay_count==0||this.goodpay.pay_count=='0'){ 
                this.$message.error("商品数量不能为零！！") 
                return;
            }
            this.$axios.post("/cart/add-to-cart",{
                good_id:this.goodpay.good_id,
                user_id:this.goodpay.user_id,
                cart_count:this.goodpay.pay_count,
            })
            .then(res => {
                console.log(res)
                this.$message.success("添加购物车成功")
            })
            .catch(err => {
                console.error(err); 
            })
        },
        //购买
        payGood(){
            let date = dateFormat(new Date())
            if(this.goodpay.pay_count==0||this.goodpay.pay_count=='0'){ 
                this.$message.error("商品数量不能为零！！") 
                return;
            }
            this.$axios.post("/order/create-order",{
                good_id:this.goodpay.good_id,
                user_id:this.goodpay.user_id,
                good_count:this.goodpay.pay_count,
                order_createdate:date,
            })
            .then(res => {
                console.log(res)
                if(res.data.code!=200) return this.$message.error(res.data.message);
                this.getGoodById(this.good_id)
                this.$message.success('已经生成订单，请前往订单中心支付');
                this.$router.push('/user/orders')
            })
            .catch(err => {
                console.error(err); 
            })
        },
        addComment(){
            this.addCommentDialogVisible = true
        },
        showAddComment(data){
            this.addCommentDialogVisible = data
        },
        getComment(gooodid){
            this.$axios.get("/commit/getCommitByGoodId",{params:{
                good_id:gooodid
            }})
            .then(res => {
                console.log(res)
                this.commitList = res.data.data
                for(let i=0;i<res.data.data.length;i++)
                    this.commitList[i].index = i
            })
            .catch(err => {
                console.error(err); 
            })
        }
    }
}


</script>




<style>
.block{
    width: 100%;
    margin: auto;
    border: 1px solid #010d14;
    border-radius: 5px;
    margin-bottom: 15px;
    padding: 15px;
}
.carousel{
    width: 100%;
    margin-top: 15px;
    padding-top: 15px;
}
.img{
    width: 30%;
    float: left;
}
.text{
    margin-left:10px;
    width: 20%;
    float:left;
}
.comment{
    margin-left:10px;
    width: 40%;
    float:right;
    margin-right:20px;
}
.content{
    height: auto;
}
.comment-cart{
   margin: 10px; 
}
.comment-cart-date{
    float: right;
}
.good-name{
    background-color:#5a1eff;
    color:#FFFFFF;
    size: 15px;
    width: 80px;
    text-align: center;
    border-radius: 5px;
}
.text-p{
    margin: 5px;
    padding: 5px;
}
</style>