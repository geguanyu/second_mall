<template>
<el-card style="width:50%;margin: auto;">
  <div>
    <el-breadcrumb separator-class="el-icon-arrow-right">
        <el-breadcrumb-item :to="{ path: '/user_home' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>发布商品</el-breadcrumb-item>
    </el-breadcrumb>
  </div>
  <good-from v-bind:uid="user_id"></good-from>
</el-card>
</template>
<script>
import GoodForm from '../../../components/good/GoodFrom'
export default {
  components:{
    'good-from':GoodForm,
  },
  date(){
    return{
      user_id:1,
    }
  },
  created(){
    this.user_id = window.sessionStorage.getItem('userId')
  }
}
</script>
<style>

</style>
  