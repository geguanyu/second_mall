<template>
<el-row>
  <div>
    <el-breadcrumb separator-class="el-icon-arrow-right">
        <el-breadcrumb-item :to="{ path: '/user_home' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>购物车</el-breadcrumb-item>
    </el-breadcrumb>
    </div>
  <el-col :span="6" v-for="item in cartGoodList" :key="item.cart_id" >
    <el-card class="cart-card" >
      <div class="shop">
        <div class="cart-checkbox"><el-checkbox v-model="item.select" true-label="1" false-label=0 @change="selectChange"></el-checkbox></div>
        <div class="shop-txt"><span >{{item.username}}</span></div>
        <div class="shop-button">
           <el-button type="danger" size="mini" @click="deleteCart(item.cart_id)">删除</el-button>
          <el-button type="primary" size="mini" @click="payGood(item.index)">支付</el-button>
        </div>
      </div>
      <div class="item-list"> </div>
      <div class="good">
        <div class="cell p-img"><el-image :src="item.good_p1"  fit="cover" ></el-image></div>
        <div class="cell p-text">
          <div><span style="font-size:10px">{{item. good_name}}-{{item.good_describe}}</span></div>
          <div><span style="font-size:10px">库存：{{item. good_count}}</span></div>
          <div><span style="font-size:15px;color: blue">￥{{item.good_price*item.cart_count}}</span></div>
          <div class="p-button">
            <el-input-number v-model="item.cart_count" @change="countChange" :min="0" :max="5>=item.good_count?item.good_count:5" size="small"></el-input-number>
          </div>
        </div>
      </div>
    </el-card>
  </el-col>
</el-row>

</template>

<script>
import {dateFormat} from '../../../utils/dateUtil'
export default {
  data(){
    return{
      userid:1,
      cartGoodList:[
        { index:0,
          cart_id:1,
          good_id:0,
          username:'范广胜',//商品发布者
          good_name:'哇哈哈',
          good_describe:'第三个覅十多个覅一个屌丝发一个屌丝一个',
          good_p1:'https://img2.baidu.com/it/u=2666157028,2545819682&fm=26&fmt=auto&gp=0.jpg',
          good_price:80,
          good_count:4,
          cart_count:0,
          select:-1,
        },
  
      ],
    }
  },
  created(){
    let uid = window.sessionStorage.getItem('userId')
    this.userid = uid
    this.getCartList(uid)
  },
  methods:{
      getCartList(userid){
        this.$axios.get("/cart/getCartList",{params:{
          user_id:userid
        }})
        .then(res => {
          console.log(res)
          this.cartGoodList = res.data.data
          for(let i = 0;i<res.data.data.length;i++){
            this.cartGoodList[i].good_p1 = require('../../../assets/img/'+res.data.data[i].good_p1)
            this.cartGoodList[i].index = i
          }
        })
        .catch(err => {
          console.error(err); 
        })
      },
    //数量变化
     countChange(value) {
       console.log(value);
      },
      //是否选中
      selectChange(value){
        console.log(value);
        
      },
      //删除购物车
      deleteCart(id){
        this.$axios.delete("/cart/deleteById",{params:{
          id:id,
        }})
        .then(res => {
          console.log(res)
          this.getCartList(this.userid);
        })
        .catch(err => {
          console.error(err); 
        })

      },
      //支付购物车
      payGood(index){
        let date = dateFormat(new Date())
         if(this.cartGoodList.cart_count==0||this.cartGoodList.cart_count=='0'){ 
                this.$message.error("商品数量不能为零！！") 
                return;
            }
          this.$axios.post("/order/create-order",{
                good_id:this.cartGoodList[index].good_id,
                user_id:this.cartGoodList[index].user_id,
                good_count:this.cartGoodList[index].cart_count,
                order_createdate:date,
            })
            .then(res => {
                console.log(res)
                this.deleteCart(this.cartGoodList[index].cart_id)
                this.getCartList()
            })
            .catch(err => {
                console.error(err); 
            })

      },
  },

}
</script>

<style>
.cart-card{
  padding: 0px ;
  height: 160px; 
}
.shop{
  height: 30px;
  line-height: 30px;
  padding-left: 11px;
}
.cart-checkbox {
    z-index: 3;
    float: left;
    margin-right: 5px;
}
.shop-txt {
    float: left;
    width: 30%;
}
.shop-button{
  float: right;
}
.item-list {
    border: 1px solid #f1f1f1;
    border-top: 2px solid #aaa;
    background: #fff;
}
.good{
  height: 100px;
  padding-bottom:5px;
  display: inline-block;
  width: 100%;
}
.cell {
    float: left;
    padding: 5px 0 4px;
}
 .p-img {
    position: relative;
    float: left;
    width: 120px;
    height: 100%;
    border: 1px solid #eee;
    margin-right: 10px;
    background: #fff;
    padding: 2px;
    text-align: center;
    overflow: visible;
}
.p-text{
  width: 160px;
  height: 100%;
}
.p-button{
  float:lift;
}

</style>