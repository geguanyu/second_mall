import Vue from 'vue'
import VueRouter from 'vue-router'

// 懒加载
//引入用户路由
const UserLogin = () => import('views/user/login/Login')
const UserHome = () => import('views/user/Home')
const UserRegister = () => import('views/user/login/Register')
const UserCart = () => import('views/user/cart/Cart')
const UserOrderList = () => import('views/user/orders/OrderList')
const PostGoods = () => import('views/user/goods/PostGoods')
const GoodMore = () => import('views/user/goods/Goodmore')
const UserGoodList = () => import('views/user/goods/GoodList')
Vue.use(VueRouter)
const routes = [
  {path:'/',redirect: '/user_login'},
  {path:'/user_login',component: UserLogin},
  {path:'/user_home',component: UserHome},
  {path:'/user_register',component: UserRegister},
  {path:'/user/cart',component: UserCart},
  {path:'/user/orderList',component: UserOrderList},
  {path:'/user/post-goods',component: PostGoods},
  {path:'/user/good/goodmore',component: GoodMore},
  {path:'/user/hava-goods',component: UserGoodList} 
]



const router = new VueRouter({
  mode: 'history',
  routes
})

export default router
