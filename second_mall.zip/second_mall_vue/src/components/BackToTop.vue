/* 回到顶部 */
<template>
  <el-backtop  :bottom="40" :right="40" :visibility-height="20">
    <div
      style="{
        height: 100%;
        width: 100%;
        background-color: #f2f5f6;
        box-shadow: 0 0 6px rgba(0,0,0, .12);
        text-align: center;
        line-height: 40px;
        color: #1989fa;
      }"
    >
      回到顶部
    </div>
  </el-backtop>
</template>