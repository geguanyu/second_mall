<template>
<el-container>
    <el-header>
    <div style="display: flex;align-items:center;">
        <img style="height: 40px" src="../assets/img/bistu.jpg" alt />
        <span sty=" margin-left:15px ;">校园二手交易市场</span>
    </div>
    <!-- 搜索 -->
    <div style="width:490px;height:40px">
        <el-input placeholder="请输入内容"  class="input-with-select"  v-model="select">
            <el-button slot="append" icon="el-icon-search" @click="findSelect"></el-button>
        </el-input>
    </div>
      <div style="right: 0px;height:40px">  
        <el-popover placement="top" width="160" v-model="userPopover">
          <el-menu  class="el-menu-demo" router>
            <el-menu-item :index="item.path"  v-for="item in userMenu" :key="item.id">
              <template slot="title">
                    <!-- 图标 -->
                    <i :class="item.icon"></i>
                    <!-- 文本 -->
                    <span>{{item.authName}}</span>
                </template>
            </el-menu-item>
            <!-- 退出 -->
          <el-menu-item index="1" @click="logout" >
            <template slot="title">
                    <!-- 图标 -->
                    <i class="el-icon-turn-off"></i>
                    <!-- 文本 -->
                    <span>退出登录</span>
                </template>
          </el-menu-item>
          </el-menu>
          <el-button slot="reference" type="info" icon="el-icon-user" circle></el-button>
        </el-popover>
      </div>
      </el-header>
</el-container>
</template>

<script>
export default {
data(){
        return{
          /* 右上用户弹出菜单*/
          userPopover: false,
          select:'',
          userMenu:[{
                id: 1,
                authName:'购物车',
                path:'/user/cart',
                icon:'el-icon-shopping-cart-full',
            },{
                id: 2,
                authName:'订单中心',
                path:'/user/orderList',
                icon:'el-icon-s-order',
            },{
                id: 3,
                authName:'个人信息',
                path:'/user/info',
                icon:'el-icon-user',
            },
            {
                id: 4,
                authName:'修改或补充信息',
                path:'/user/edit-user',
                icon:'el-icon-s-custom',
            },
            {
                id: 5,
                authName:'学籍认证',
                path:'/user/check/edit-student',
                icon:'el-icon-s-check',  
            },{
                id: 6,
                authName:'发布商品',
                path:'/user/post-goods',
                icon:'el-icon-sell',  
            },
            {
                id: 7,
                authName:'已发布商品',
                path:'/user/hava-goods',
                icon:'el-icon-goods',  
            },
            ]
        }
    },
    methods:{
        logout () {
            this.$router.push('/user_login')
            },
        findSelect(){
            this.$emit("find",this.select)
        }
    }
}
</script>

<style>

</style>