<template>
<el-row>
  <el-col :span="8" v-for="good in goodList" :key="good.good_id">
    <el-card  class="card">
        <div class="imgDiv">
            <img :src="good.good_p1" class="img" @click="togoodmore(good.good_id)" style="80%">
        </div>
        <div class="textDiv">
        <div class="text-p"><span>{{good.good_category}}:{{good.good_describe}}</span></div>
        <div class="text-p"><span style="color:red">￥{{good.good_price}}</span></div>
        </div>
    </el-card>
  </el-col>
</el-row>
</template>

<script>

export default {
    props:['good_serach'],
    data(){
        return{
            //pathimg:'../../assets/img',
            good_select:'',
            goodList:[{
                good_p1:'https://shadow.elemecdn.com/app/element/hamburger.9cf7b091-55e9-11e9-a976-7f4d0b07eef6.png',
                good_describe:'上的灌水灌水灌水的公司的',
                good_price:136,//价格
                good_id:0,
            },{
                good_p1:'https://cube.elemecdn.com/6/94/4d3ea53c084bad6931a56d5158a48jpeg.jpeg',
                good_describe:'爱上发发打发二分',
                good_price:236,//价格
                good_id:1,
            },
            {
                good_p1:'https://shadow.elemecdn.com/app/element/hamburger.9cf7b091-55e9-11e9-a976-7f4d0b07eef6.png',
                good_describe:'上的灌水灌水灌水的公司的',
                good_price:136,//价格
                good_id:2,
            },{
                good_p1:'https://cube.elemecdn.com/6/94/4d3ea53c084bad6931a56d5158a48jpeg.jpeg',
                good_describe:'爱上发发打发二分',
                good_price:236,//价格
                good_id:3,
            },],

            
        }
    },
    created(){
        this.good_select = this.good_serach
        console.log("搜索："+this.good_select)
        this.getGoodListByCategory(this.good_select)
    },
    watch:{
        good_serach :function(val, oldVal){
            console.log(val, oldVal);
            this.good_select = this.good_serach
            console.log("搜索："+this.good_select)
            this.getGoodListByCategory(this.good_select)
        }
    },
    methods:{
        togoodmore(good_id){
            console.log(good_id);
            this.$router.push( {path: '/user/good/goodmore',query: { good_id: good_id }})
        },
        //获得商品列表
        getGoodListByCategory(serach){
            this.$axios.get("/good/getGoodlist-by-category",{params:{
                serach:serach,
            }})
            .then(res => {
                console.log(res)
                this.goodList=res.data.data
                let n = res.data.data.length
                for(let i=0;i<n;i++){
                    console.log(this.goodList[i].good_p1)
                    this.goodList[i].good_p1 =require('../../assets/img/'+res.data.data[i].good_p1)
                    console.log(this.goodList[i].good_p1)
                }
                console.log("goodList:");
                console.log(this.goodList);
            })
            .catch(err => {
                console.error(err); 
            })
        }
    }


}


</script>




<style>
.card{
    padding: 5px;
    height: 320px;
}
.imgDiv{
    margin: auto;
    width: 60%;
    height: 280px;
    float: left;
}
.textDiv{
    line-height:1.3 ;
    margin-left: 0;
    width: 40%;
    float:right;
}
.img{
    margin: auto;
    width: 100%;
    height:80%;
}
.text-p{
    margin: 5px;
    height: 60px;
    padding: 5px;
}

</style>