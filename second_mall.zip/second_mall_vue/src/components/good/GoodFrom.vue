<template>
<el-form ref="goodform" :model="goodFrom" label-width="80px" style="width:100%">
    <el-form-item label="商品名字">
      <el-input v-model="goodFrom.good_name"></el-input>
    </el-form-item>
    <el-form-item label="商品类别">
      <el-select v-model="goodFrom.good_category" placeholder="请选择">
        <el-option
          v-for="item in category"
          :key="item.value"
          :label="item.label"
          :value="item.label">
        </el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="商品描述">
      <el-input v-model="goodFrom.good_describe"></el-input>
    </el-form-item>
    <el-form-item label="商品价格">
      <el-input v-model="goodFrom.good_price"></el-input>
    </el-form-item>
    <el-form-item label="商品数量">
      <el-input v-model="goodFrom.good_count"></el-input>
    </el-form-item>
    <el-form-item label="商品照片" >
      <el-input v-model="goodFrom.good_p1" autocomplete="off" placeholder="图片 URL"></el-input>
      <img-upload @onUpload="uploadImg1" ref="imgUpload1"></img-upload>
      <el-input v-model="goodFrom.good_p2" autocomplete="off" placeholder="图片 URL"></el-input>
      <img-upload @onUpload="uploadImg2" ref="imgUpload2"></img-upload>
      <el-input v-model="goodFrom.good_p3" autocomplete="off" placeholder="图片 URL"></el-input>
      <img-upload @onUpload="uploadImg3" ref="imgUpload3"></img-upload>
    </el-form-item>
    <el-form-item>
      <el-button type="success" style="float:right;margin-right: 10px;"  @click="commitFrom">发布</el-button>
      <el-button type="danger" style="float:right;margin-right: 15px;" >取消</el-button>
    </el-form-item>
  </el-form>
</template>
<script>
import UpLoadImg from "../ImgUpload"
import {dateFormat} from "../../utils/dateUtil"
export default {
  props:['uid'],
  components:{
    "img-upload":UpLoadImg,
    },
    created(){
      this.goodFrom.user_id = this.uid;
    },
  data(){
    return{
      goodFrom:{
        user_id:1,
        good_category:'',//类别
        good_name:'',//商品名
        good_describe:'',//商品描述
        good_price:0,//价格
        good_postdate:'',//发布日期
        good_status:0,//商品状态
        good_count:1,//商品数量
        good_p1:'',
        good_p2:'',
        good_p3:'',
      },
      category:[{
          value: '选项1',
          label: '文体用品'
        }, {
          value: '选项2',
          label: '书籍'
        }, {
          value: '选项3',
          label: '电子产品'
        }, {
          value: '选项4',
          label: '服装'
        }, {
          value: '选项5',
          label: '饰品精品'
        },{
          value: '选项6',
          label: '其他'
        }],
    }
  },
  methods:{
    uploadImg1(){
      this.goodFrom.good_p1=this.$refs.imgUpload1.url;
      console.log(this.goodFrom.good_p1);
    },
    uploadImg2(){
      this.goodFrom.good_p2=this.$refs.imgUpload2.url;
      console.log(this.goodFrom.good_p2);
    },
    uploadImg3(){
      this.goodFrom.good_p3=this.$refs.imgUpload3.url;
      console.log(this.goodFrom.good_p3);
    },
    commitFrom(){
      let date = new Date()
      this.goodFrom.good_postdate = dateFormat(date)
      if(this.goodFrom.good_count<=0) return this.$message.error('商品数量必须大于零')
      if(this.goodFrom.good_p1 ==''||this.goodFrom.good_p2==''||this.goodFrom.good_p3=='') return this.$message.error('请上传三张照片！！')
      console.log(this.goodFrom);
      this.$axios.post("/good/post-good",{
        user_id:this.goodFrom.user_id,
        category:this.goodFrom.good_category,//类别
        good_name:this.goodFrom.good_name,//商品名
        good_describe:this.goodFrom.good_describe,//商品描述
        good_price:this.goodFrom.good_price,//价格
        good_postdate:this.goodFrom.good_postdate,//发布日期
        good_status:0,//商品状态
        good_count:this.goodFrom.good_count,//商品数量
        good_p1:this.goodFrom.good_p1,
        good_p2:this.goodFrom.good_p2,
        good_p3:this.goodFrom.good_p3,
      })
      .then(res => {
        console.log(res)
        if(res.data.code!=200) this.$message.error("发布失败！！");
        this.$message.success("发布成功！！");
        this.$router.push("/user_home");
      })
      .catch(err => {
        console.error(err); 
      })
    },

  }
}
</script>

<style>

</style>