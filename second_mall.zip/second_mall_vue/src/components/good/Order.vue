<template>
<div class="block">
  <el-timeline>
    <el-timeline-item
      v-for="(activity, index) in orderActive"
      :key="index"
      :color="activity.color"
      :type="activity.type"
      :timestamp="activity.timestamp">
      {{activity.content}}
    </el-timeline-item>
  </el-timeline>
</div>
</template>
<script>
export default {
  props:['orderid'],
    data(){
        return{
          orderId:0,
            order:{
                order_id:544964,
                order_createdate:'2018-04-01 20:46',//0
                order_paydate:'2018-04-06 20:46',//1
                order_changedate:'2018-04-07 20:46',//2
                order_finishdate:'2018-04-08 20:46',//3
                order_status:1,
            },
            orderActive: [{
                content: '创建时间',
                timestamp: '',
                type:'success'
                }, {
                content: '支付时间',
                timestamp: '',
                 type:''
                }, {
                content: '送达学校',
                timestamp: '2018-04-03 20:46',
                 type:''
                }, {
                content: '完成时间',
                timestamp: '',
                type:''
                }, {
                content: '完成时间',
                timestamp: '',
                type:''
                }],
        }
    },
    created(){
      this.orderId=parseInt(this.orderid);
      this.getOderById(this.orderId)
    },
    watch:{
       orderid:function(val, oldVal){
            this.getOderById(val)
        }
    },
    methods:{
      getOderById(id){
        this.$axios.get("/oder/getOderById",{params:{
          order_id:id
        }})
        .then(res => {
          console.log(res)
          this.order = res.data.data
          let k = this.order.order_status
          console.log(k);
          this.orderActive[0].timestamp=this.order.order_createdate
          this.orderActive[0].content='创建时间';
          this.orderActive[1].timestamp=this.order.order_paydate
          this.orderActive[1].content='支付时间';
          this.orderActive[2].timestamp=this.order.order_exchangedate
          this.orderActive[2].content='送达中转';
          this.orderActive[3].timestamp=this.order.order_change
          this.orderActive[3].content='离开中转';
          this.orderActive[4].timestamp=this.order.order_finish
          this.orderActive[4].content='完成';
          for(let i = 0;i<5;i++){
            //console.log(this.orderActive[i]);
            if(i<=k)this.orderActive[i].type='success'
            else this.orderActive[i].type=''
          }
        })
        .catch(err => {
          console.error(err); 
        })
      }
      
    }

}

</script>

<style>


</style>